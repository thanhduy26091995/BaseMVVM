package com.duybui.basemvvmjava.ui.base;

public interface OnClickButtonListener {
    void onPositiveButtonClicked();
}
