package com.duybui.basemvvmjava.utils;

public final class AppConstants {
    public static final String TITLE = "TITLE";
    public static final String BODY = "BODY";

    public static final String BASE_URL = "https://randomuser.me";
}
