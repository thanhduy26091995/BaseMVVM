package com.duybui.basemvvmjava;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.duybui.basemvvmjava.data.network.ApiInterface;
import com.duybui.basemvvmjava.data.response.RandomUserResponse;
import com.duybui.basemvvmjava.ui.base.BaseActivity;
import com.duybui.basemvvmjava.ui.base.DialogsManager;
import com.duybui.basemvvmjava.ui.base.ServerErrorDialogFragment;
import com.duybui.basemvvmjava.ui.users.UserAdapter;

import javax.inject.Inject;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends BaseActivity {

    @Inject
    Retrofit retrofit;
    @Inject
    DialogsManager dialogsManager;
    @Inject
    UserAdapter userAdapter;

    @BindView(R.id.rv_users)
    RecyclerView mRecycler;

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getPresentationComponent().inject(this);

        setupRecyclerView();

        ApiInterface apiInterface = retrofit.create(ApiInterface.class);
        apiInterface.getRandomUser(10).enqueue(new Callback<RandomUserResponse>() {
            @Override
            public void onResponse(Call<RandomUserResponse> call, Response<RandomUserResponse> response) {
                Log.d(TAG, response.body().getUsers().size() + "");
                userAdapter.setData(response.body().getUsers());
            }

            @Override
            public void onFailure(Call<RandomUserResponse> call, Throwable t) {

            }
        });
    }

    private void setupRecyclerView() {
        mRecycler.setLayoutManager(new LinearLayoutManager(this));
        mRecycler.setAdapter(userAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
