package com.duybui.basemvvmjava.di.service;

import dagger.Subcomponent;

@Subcomponent(modules = ServiceModule.class)
public interface ServiceComponent {

}
